//
//  WTTViewModel.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "WTTNetManager.h"
@interface WTTViewModel : BaseViewModel
@property (nonatomic)NSInteger rowNumber;
- (id)initWithNewsListType:(InfoType)type;
@property (nonatomic)InfoType type;

- (NSURL *)iconForRow:(NSInteger)row;

- (NSString *)titleForRow:(NSInteger)row;

- (NSInteger)clickForRow:(NSInteger)row;

@property (nonatomic)NSInteger nextTime;

@property (nonatomic,strong)NSString *nextSign;

- (NSString *)PathIdForRow:(NSInteger)row;
- (NSString *)PathAckForRow:(NSInteger)row;
@end
