//
//  sportVidoeVIewModel.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "sportVidoeNetManager.h"
@interface sportVidoeVIewModel : BaseViewModel

@property (nonatomic)NSInteger rowNumber;

- (NSURL *)iconForRow:(NSInteger)row;

- (NSString *)titleForRow:(NSInteger)row;

- (NSString *)clikeForRow:(NSInteger)row;

- (NSString *)timeForRow:(NSInteger)row;

@property (nonatomic,strong)NSString *vid;

- (NSString *)pathForRow:(NSInteger)row;



@end
