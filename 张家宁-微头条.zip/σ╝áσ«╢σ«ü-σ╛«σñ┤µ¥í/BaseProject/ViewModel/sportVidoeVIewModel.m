//
//  sportVidoeVIewModel.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportVidoeVIewModel.h"

@implementation sportVidoeVIewModel

- (NSInteger)rowNumber
{
    return self.dataArr.count;
}
- (NSURL *)iconForRow:(NSInteger)row
{
    NSString *path = [self modelForRow:row].cover;
    return [NSURL URLWithString:path];
}

- (NSString *)titleForRow:(NSInteger)row
{
    return [self modelForRow:row].title;
}

- (NSString *)clikeForRow:(NSInteger)row
{
    return [self modelForRow:row].replies;
}
- (NSString *)timeForRow:(NSInteger)row
{
    return [self modelForRow:row].playtime;
}

- (sportVidoeResultDataModel *)modelForRow:(NSInteger)row
{
   return self.dataArr[row];
}

- (NSString *)pathForRow:(NSInteger)row
{
    return [self modelForRow:row].fromurl;
}


- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    [sportVidoeNetManager getSportVidoeWithVid:self.vid completionHandle:^(sportVidoeModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.result.data];
        completionHandle(error);
        self.vid = model.result.data.lastObject.vid;
    }];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.vid = @"0";
    [self getDataFromNetCompleteHandle:completionHandle];
}

@end
