//
//  RankListVIewModel.h
//  微头条
//
//  Created by apple-jd20 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "RankNetManager.h"
@interface RankListVIewModel : BaseViewModel
- (id)initWithType:(RankType)type;

@property (nonatomic)RankType type;

@property (nonatomic)NSInteger rowNumber;

- (NSURL *)iconForRow:(NSInteger)row;

- (NSString *)titleForRow:(NSInteger)row;

- (NSInteger)cilkeForRow:(NSInteger)row;
- (NSString *)PathAckForRow:(NSInteger)row;
- (NSString *)pathStreamForRow:(NSInteger)row;

@end
