//
//  sportViewModel.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportViewModel.h"

@implementation sportViewModel

- (NSInteger)rowNumber
{
    return self.dataArr.count;
}

- (sportResultDataModel *)modelForRow:(NSInteger)row
{
    return self.dataArr[row];
}
-(NSURL *)iconForRow:(NSInteger)row
{
    NSString *path = [self modelForRow:row].img;
    return [NSURL URLWithString:path];
}
- (NSString *)titleForRow:(NSInteger)row
{
    return [self modelForRow:row].title;
}
- (NSString *)clickForRow:(NSInteger)row
{
    return [self modelForRow:row].replies;
}
- (NSString *)descForRow:(NSInteger)row
{
    return [self modelForRow:row].summary;
}

- (BOOL)isHasIconForRow:(NSInteger)row
{
    return [self modelForRow:row].thumbs ? YES : NO;
}

- (NSString *)path0ForRow:(NSInteger)row
{
    return [self modelForRow:row].thumbs.firstObject;
}
- (NSString *)path1ForRow:(NSInteger)row
{
    return [self modelForRow:row].thumbs[1];
}
- (NSString *)path2ForRow:(NSInteger)row
{
    return [self modelForRow:row].thumbs.lastObject;
}

- (NSString *)sportdescForRow:(NSInteger)row
{
    return [self modelForRow:row].nid;
}


- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    [sportNetManager getSportWithNib:self.nid completionHandle:^(sportModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.result.data];
        self.nid = model.result.data.lastObject.nid;
//        self.lastNid = model.result.data.lastObject.nid;
        completionHandle(error);
    }];
    
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.nid = @"0";
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
//    _nid = _lastNid;
    [self getDataFromNetCompleteHandle:completionHandle];
}

@end
