//
//  WTTViewModel.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/6.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTViewModel.h"

@implementation WTTViewModel

- (id)initWithNewsListType:(InfoType)type
{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}

- (NSInteger)rowNumber
{
    return self.dataArr.count;
}
- (NSURL *)iconForRow:(NSInteger)row
{
    NSString *path = [self modelForRow:row].img_src;
    return [NSURL URLWithString:path];
}
- (NSString *)titleForRow:(NSInteger)row
{
    return [self modelForRow:row].title;
}
- (NSInteger)clickForRow:(NSInteger)row
{
    return [self modelForRow:row].visit_num;
}

- (NSString *)PathIdForRow:(NSInteger)row
{
    return [self modelForRow:row].Id;
}

- (NSString *)PathAckForRow:(NSInteger)row
{
    return [self modelForRow:row].ack_code;
}

- (WTTDataListModel *)modelForRow:(NSInteger)row
{
    return self.dataArr[row];
}


- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle
{
//    self.nextTime = obj.nexttime;
//    self.nextSign = obj.nextsign;
    [self getDataFromNetCompleteHandle:completionHandle];
}
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    [WTTNetManager getOtherListWithType:_type Lasttime:self.nextTime cateSign:self.nextSign completionHandle:^(WTTModel *model, NSError *error) {
        if (self.nextTime == 0) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data.list];
        self.nextTime = model.data.nexttime;
        self.nextSign = model.data.nextsign;
        completionHandle(error);
        
    }];
}
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle
{
    self.nextTime = 0;
    self.nextSign = @"null";
    [self getDataFromNetCompleteHandle:completionHandle];
}

@end
