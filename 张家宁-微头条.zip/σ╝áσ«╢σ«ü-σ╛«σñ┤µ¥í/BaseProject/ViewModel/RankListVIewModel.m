//
//  RankListVIewModel.m
//  微头条
//
//  Created by apple-jd20 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankListVIewModel.h"

@implementation RankListVIewModel

- (id)initWithType:(RankType)type
{
    if (self = [super init]) {
        _type = type;
    }
    return self;
}

- (NSInteger)rowNumber
{
    return self.dataArr.count;
}

- (RankListDataListModel *)modelForRow:(NSInteger)row
{
    return self.dataArr[row];
}
- (NSURL *)iconForRow:(NSInteger)row
{
    NSString *path = [self modelForRow:row].img_src;
    return [NSURL URLWithString:path];
}
- (NSString *)titleForRow:(NSInteger)row
{
    return [self modelForRow:row].title;
}

- (NSInteger)cilkeForRow:(NSInteger)row
{
    return [self modelForRow:row].visit_num;
}

- (NSString *)PathAckForRow:(NSInteger)row
{
    return [self modelForRow:row].ack_code;
}
- (NSString *)pathStreamForRow:(NSInteger)row
{
    return [self modelForRow:row].stream_id;
}

- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle
{
    [RankNetManager getRankListWithType:self.type completionHandle:^(RankListModel *model, NSError *error) {
        [self.dataArr addObjectsFromArray:model.data.list];
        completionHandle(error);
    }];
}


@end
