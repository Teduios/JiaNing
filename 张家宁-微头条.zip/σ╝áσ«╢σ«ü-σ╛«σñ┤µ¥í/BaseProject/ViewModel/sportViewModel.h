//
//  sportViewModel.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "sportNetManager.h"
@interface sportViewModel : BaseViewModel

@property (nonatomic)NSInteger rowNumber;

- (NSURL *)iconForRow:(NSInteger)row;

- (NSString *)titleForRow:(NSInteger)row;

- (NSString *)clickForRow:(NSInteger)row;

- (NSString *)descForRow:(NSInteger)row;

@property (nonatomic,strong)NSString *nid;

@property (nonatomic, strong)NSString *lastNid;

- (BOOL)isHasIconForRow:(NSInteger)row;

- (NSString *)path0ForRow:(NSInteger)row;
- (NSString *)path1ForRow:(NSInteger)row;
- (NSString *)path2ForRow:(NSInteger)row;
- (NSString *)sportdescForRow:(NSInteger)row;
@end
