//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "WelcomeViewController.h"
#import "WTTViewController.h"
#import "UMSocial.h"
#import "UMSocialWechatHandler.h"
//#import "UMSocial.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
 
    [self initializeWithApplication:application];
    [UMSocialData setAppKey:@"5652c654e0f55a3377002c42"];
    [UMSocialWechatHandler setWXAppId:@"wx3efeabf3380f9f66" appSecret:@"d4624c36b6795d1d99dcf0547af5443d" url:@"http://www.umeng.com/social"];
    
    
    NSDictionary *info = [[NSBundle mainBundle] infoDictionary];
    NSString *key = @"CFBundleShortVersionString";
    NSString *currentversion = info[key];
    NSString *runVersion = [[NSUserDefaults standardUserDefaults] stringForKey:key];
    if (runVersion == nil||![runVersion isEqualToString:currentversion]) {
        self.window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
        WelcomeViewController *vc = [WelcomeViewController new];
        
        self.window.rootViewController = vc;
        [self.window makeKeyAndVisible];
        [[NSUserDefaults standardUserDefaults] setValue:currentversion forKey:key];
//        [self.window makeKeyAndVisible];
    }
   
    
//    self.window.rootViewController = [MyTabBarController new];

    
    return YES;
}



@end
