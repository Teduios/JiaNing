//
//  sportVidoeModel.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportVidoeModel.h"

@implementation sportVidoeModel

@end
@implementation sportVidoeResultModel

+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [sportVidoeResultDataModel class]};
}

@end


@implementation sportVidoeResultDataModel

@end


