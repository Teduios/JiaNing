//
//  sportModel.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportModel.h"

@implementation sportModel

@end
@implementation sportResultModel

+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [sportResultDataModel class]};
}

@end


@implementation sportResultDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"badge" : [sportResultDataBadgeModel class]};
}

@end


@implementation sportResultDataBadgeModel

@end


