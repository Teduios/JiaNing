//
//  RankListModel.m
//  微头条
//
//  Created by apple-jd20 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankListModel.h"

@implementation RankListModel

@end
@implementation RankListExtModel

@end


@implementation RankListDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [RankListDataListModel class]};
}

@end


@implementation RankListDataListModel

@end


@implementation RandListDataListDisplaymodel

@end


@implementation RandListDataListActionModel

@end


