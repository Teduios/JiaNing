//
//  RankListModel.h
//  微头条
//
//  Created by apple-jd20 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class RankListExtModel,RankListDataModel,RankListDataListModel,RandListDataListDisplaymodel,RandListDataListActionModel;
@interface RankListModel : BaseModel

@property (nonatomic, assign) BOOL status;

@property (nonatomic, strong) RankListDataModel *data;

@property (nonatomic, strong) RankListExtModel *ext;

@property (nonatomic, assign) NSInteger count;

@end
@interface RankListExtModel : NSObject

@property (nonatomic, copy) NSString *inter_url;

@property (nonatomic, assign) NSInteger c_time;

@end

@interface RankListDataModel : NSObject

@property (nonatomic, strong) NSArray<RankListDataListModel *> *list;

@end

@interface RankListDataListModel : NSObject

@property (nonatomic, copy) NSString *stream_id;

@property (nonatomic, copy) NSString *is_rec;

@property (nonatomic, copy) NSString *src_id;

@property (nonatomic, copy) NSString *src_link;

@property (nonatomic, copy) NSString *Id;

@property (nonatomic, copy) NSString *pubtime;

@property (nonatomic, strong) RandListDataListDisplaymodel *display;

@property (nonatomic, copy) NSString *ack_code;

@property (nonatomic, assign) NSInteger topic_id;

@property (nonatomic, copy) NSString *src_title;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img_src;

@property (nonatomic, copy) NSString *summary;

@property (nonatomic, strong) RandListDataListActionModel *action;

@property (nonatomic, copy) NSString *ncate_id;

@property (nonatomic, assign) NSInteger visit_num;

@property (nonatomic, copy) NSString *cate_id;

@end

@interface RandListDataListDisplaymodel : NSObject

@property (nonatomic, copy) NSString *type;

@property (nonatomic, assign) NSInteger value;

@end

@interface RandListDataListActionModel : NSObject

@property (nonatomic, copy) NSString *target;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *value;

@end

