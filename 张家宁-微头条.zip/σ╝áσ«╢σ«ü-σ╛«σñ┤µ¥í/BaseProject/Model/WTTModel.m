//
//  WTTModel.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTModel.h"

@implementation WTTModel

@end
@implementation WTTExtModel

+(NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName
{
    return [propertyName underlineFromCamel];
}

@end


@implementation WTTDataModel

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [WTTDataListModel class]};
}

@end


@implementation WTTDataListModel

//+(NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName
//{
//    return [propertyName underlineFromCamel];
//}

@end


@implementation WTTDataListDisplayModel

+(NSString *)replacedKeyFromPropertyName121:(NSString *)propertyName
{
    return [propertyName underlineFromCamel];
}

@end


@implementation WTTDataListActionModel

@end


