//
//  sportVidoeModel.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class sportVidoeResultModel,sportVidoeResultDataModel;
@interface sportVidoeModel : BaseModel

@property (nonatomic, strong) sportVidoeResultModel *result;

@property (nonatomic, assign) NSInteger is_login;

@end
@interface sportVidoeResultModel : NSObject

@property (nonatomic, assign) NSInteger nextDataExists;

@property (nonatomic, strong) NSArray<sportVidoeResultDataModel *> *data;

@property (nonatomic, assign) NSInteger open;

@end

@interface sportVidoeResultDataModel : NSObject

@property (nonatomic, copy) NSString *playtime;

@property (nonatomic, copy) NSString *replies;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *vid;

@property (nonatomic, copy) NSString *cover;

@property (nonatomic, copy) NSString *fromurl;

@end

