//
//  sportModel.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class sportResultModel,sportResultDataModel,sportResultDataBadgeModel;
@interface sportModel : BaseModel

@property (nonatomic, strong) sportResultModel *result;

@property (nonatomic, assign) NSInteger is_login;

@end
@interface sportResultModel : NSObject

@property (nonatomic, assign) NSInteger nextDataExists;

@property (nonatomic, strong) NSArray<sportResultDataModel *> *data;

@end

@interface sportResultDataModel : NSObject

@property (nonatomic, copy) NSString *uptime;

@property (nonatomic, copy) NSString *summary;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, assign) NSInteger lights;

@property (nonatomic, copy) NSString *replies;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *nid;

@property (nonatomic, strong) NSArray<sportResultDataBadgeModel *> *badge;
@property (nonatomic, strong) NSArray *thumbs;

@property (nonatomic, copy) NSString *read;

@property (nonatomic, assign) NSInteger type;

@end

@interface sportResultDataBadgeModel : NSObject

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *color;

@end

