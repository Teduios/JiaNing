//
//  uploadView.m
//  BaseProject
//
//  Created by apple-jd20 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "uploadView.h"

@implementation uploadView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (void)upload
{
    UIImageView *imageView = [UIImageView new];
    [self addSubview:imageView];
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(0);
    }];
    imageView.image = [UIImage animatedImageNamed:@"loadinganim" duration:1/10.0*6];
}

@end
