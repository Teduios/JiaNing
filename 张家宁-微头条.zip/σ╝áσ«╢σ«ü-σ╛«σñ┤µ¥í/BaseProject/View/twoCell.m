//
//  twoCell.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "twoCell.h"

@implementation twoCell



@end
