//
//  twoCell.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface twoCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *btn2;

@property (weak, nonatomic) IBOutlet UILabel *titleLb2;
@property (weak, nonatomic) IBOutlet UILabel *clicks2;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageH;
@end
