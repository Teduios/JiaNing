//
//  uploadView.h
//  BaseProject
//
//  Created by apple-jd20 on 15/12/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface uploadView : UIView



- (void)upload;


@end
