//
//  oneCell.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/10.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface oneCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *btn1;
@property (weak, nonatomic) IBOutlet UILabel *titleLb1;
@property (weak, nonatomic) IBOutlet UILabel *clicks;

@end
