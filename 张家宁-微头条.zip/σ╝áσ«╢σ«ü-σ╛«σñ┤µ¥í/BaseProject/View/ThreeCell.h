//
//  ThreeCell.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThreeCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIButton *btn;
@property (weak, nonatomic) IBOutlet UILabel *titleTb;
@property (weak, nonatomic) IBOutlet UILabel *Tb;

@end
