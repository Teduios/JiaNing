//
//  RankNetManager.m
//  微头条
//
//  Created by apple-jd20 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankNetManager.h"
#import "RankListModel.h"
@implementation RankNetManager

+(id)getRankListWithType:(RankType)type completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = nil;
    switch (type) {
        case RankTypeCuanHong:
            path = @"http://app.lerays.com/api/stream/rank/trending";
            break;
        case RankTypeZhouBang:
            path = @"http://app.lerays.com/api/stream/rank/week";
            break;
        case RankTypeYueBang:
            path = @"http://app.lerays.com/api/stream/rank/month";
            break;
        default:
            NSLog(@"有误");
            break;
    }
        
        return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
            completionHandle([RankListModel objectWithKeyValues:responseObj],error);
        }];

}

@end
