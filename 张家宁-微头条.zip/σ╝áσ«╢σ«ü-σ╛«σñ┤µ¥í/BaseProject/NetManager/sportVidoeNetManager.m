//
//  sportVidoeNetManager.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportVidoeNetManager.h"

@implementation sportVidoeNetManager
+(id)getSportVidoeWithVid:(NSString *)vid completionHandle:(void (^)(id, NSError *))completionHandel
{
    NSString *path = [NSString stringWithFormat:@"http://games.mobileapi.hupu.com/3/7.0.4/nba/getVideo?client=69baef404ada43c37989a0885456734af522cabe&night=0&num=20&vid=%@&type=rec",vid];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandel([sportVidoeModel objectWithKeyValues:responseObj],error);
    }];
}
@end
