//
//  sportVidoeNetManager.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "sportVidoeModel.h"
@interface sportVidoeNetManager : BaseNetManager
+(id)getSportVidoeWithVid:(NSString *)vid completionHandle:(void(^)(id model,NSError *error))completionHandel;
@end
