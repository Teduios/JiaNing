//
//  WTTNetManager.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "WTTModel.h"

typedef NS_ENUM(NSUInteger, InfoType) {
    InfoTypeReMen,
    InfoTypeMeiNv,
    InfoTypeHuDong,
    InfoTypeMengCong,
    InfoTypeQiQu,
    InfoTypeBaoXiao,
    InfoTypeShiPin,
    InfoTypeShengHuo,
    InfoTypeZiXun,
};
@interface WTTNetManager : BaseNetManager



+(id)getOtherListWithType:(InfoType)type Lasttime:(NSInteger)lasttime cateSign:(NSString *)sign completionHandle:(void(^)(id model,NSError *error))completionHandle;

@end
