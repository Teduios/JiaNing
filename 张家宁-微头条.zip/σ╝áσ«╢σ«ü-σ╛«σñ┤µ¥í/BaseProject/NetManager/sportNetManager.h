//
//  sportNetManager.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "sportModel.h"
@interface sportNetManager : BaseNetManager

+(id)getSportWithNib:(NSString *)nib completionHandle:(void(^)(id model,NSError *error))completionHandle;

@end
