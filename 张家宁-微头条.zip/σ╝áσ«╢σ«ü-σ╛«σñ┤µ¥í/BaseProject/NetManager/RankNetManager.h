//
//  RankNetManager.h
//  微头条
//
//  Created by apple-jd20 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "RankListModel.h"
typedef NS_ENUM(NSUInteger, RankType) {
    RankTypeCuanHong,
    RankTypeZhouBang,
    RankTypeYueBang,
};
@interface RankNetManager : BaseNetManager

+(id)getRankListWithType:(RankType)type completionHandle:(void(^)(id model,NSError *error))completionHandle;
@end
