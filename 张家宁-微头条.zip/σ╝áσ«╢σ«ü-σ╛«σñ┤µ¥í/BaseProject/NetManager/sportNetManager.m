//
//  sportNetManager.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportNetManager.h"

@implementation sportNetManager

+(id)getSportWithNib:(NSString *)nib completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSString *path = [NSString stringWithFormat:@"http://games.mobileapi.hupu.com/3/7.0.4/nba/getNews?client=69baef404ada43c37989a0885456734af522cabe&night=0&num=20&direc=next&nid=%@&preload=0",nib];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        completionHandle([sportModel objectWithKeyValues:responseObj],error);
    }];
}

@end
