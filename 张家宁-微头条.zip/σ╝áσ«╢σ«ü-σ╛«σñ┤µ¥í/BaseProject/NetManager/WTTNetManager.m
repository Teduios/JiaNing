//
//  WTTNetManager.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/5.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTNetManager.h"
#import "WTTModel.h"

#define kListPath           @"http://app.lerays.com/api/stream/list"
#define kHotPath            @"http://app.lerays.com/api/stream/hot"
@implementation WTTNetManager


+(id)getOtherListWithType:(InfoType)type Lasttime:(NSInteger)lasttime cateSign:(NSString *)sign completionHandle:(void (^)(id, NSError *))completionHandle
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithDictionary:@{@"pubtime":@(lasttime),@"cate_sign":sign,@"cate_type":@"cate"}];
    switch (type) {
        case InfoTypeReMen:
            [params removeObjectForKey:@"cate_type"];
            return [self GET:kHotPath parameters:params completionHandler:^(id responseObj, NSError *error) {
                completionHandle([WTTModel objectWithKeyValues:responseObj],error);
            }];
            
        case InfoTypeMeiNv:
            [params setObject:@"5" forKey:@"cate_list"];
            break;
        case InfoTypeHuDong:
            [params setObject:@"33" forKey:@"cate_list"];
            break;
        case InfoTypeMengCong:
            [params setObject:@"34" forKey:@"cate_list"];
            break;
        case InfoTypeQiQu:
            [params setObject:@"31" forKey:@"cate_list"];
            break;
        case InfoTypeBaoXiao:
            [params setObject:@"3" forKey:@"cate_list"];
            break;
        case InfoTypeShiPin:
            [params setObject:@"36" forKey:@"cate_list"];
            break;
        case InfoTypeShengHuo:
            [params setObject:@"35" forKey:@"cate_list"];
            break;
        case InfoTypeZiXun:
            [params setObject:@"32" forKey:@"cate_list"];
            break;
        default:
            NSLog(@"你输入的类型不对");
            break;
    }
    return [self GET:kListPath parameters:params completionHandler:^(id responseObj, NSError *error) {
        return completionHandle([WTTModel objectWithKeyValues:responseObj],error);
    }];
}

@end
