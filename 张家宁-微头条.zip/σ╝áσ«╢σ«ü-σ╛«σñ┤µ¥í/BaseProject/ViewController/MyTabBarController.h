//
//  MyTabBarController.h
//  微头条
//
//  Created by apple-jd20 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTabBarController : UITabBarController

@end
