//
//  decViewController.h
//  微头条
//
//  Created by apple-jd20 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface decViewController : UIViewController
- (id)initDecWithAck:(NSString *)ack Id:(NSString *)Id;
@property (nonatomic,strong)NSString *ack;
@property (nonatomic,strong)NSString *Id;
@end
