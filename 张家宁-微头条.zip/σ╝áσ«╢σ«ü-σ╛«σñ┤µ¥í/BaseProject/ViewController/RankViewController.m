//
//  RankViewController.m
//  微头条
//
//  Created by apple-jd20 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankViewController.h"
#import "ScrollDisplayViewController.h"
#import "RankListViewController.h"
@interface RankViewController ()<ScrollDisplayViewControllerDelegate>
@property (nonatomic,strong)ScrollDisplayViewController *sdVC;
@property (nonatomic,strong)UIScrollView *scrollView;
@property (nonatomic,strong)NSMutableArray *btns;
@property (nonatomic,strong)UIView *lineView;
@property (nonatomic,strong)UIButton *currentBtn;
@property (nonatomic,strong)UIView *naviView;

@end

@implementation RankViewController

-(void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController currentIndex:(NSInteger)index{
    _currentBtn.selected = NO;
    _currentBtn = _btns[index];
    _currentBtn.selected = YES;
    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo((kWindowW-40)/3);
        make.height.mas_equalTo(2);
        make.centerX.mas_equalTo(_currentBtn);
        make.top.mas_equalTo(_currentBtn.mas_bottom).mas_equalTo(0);
    }];
}

- (NSMutableArray *)btns
{
    if (!_btns) {
        _btns = [NSMutableArray new];
    }
    return _btns;
}

- (UIView *)lineView{
    if (!_lineView) {
        _lineView = [UIView new];
        [self.naviView addSubview:_lineView];
        [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo((kWindowW-40)/3);
            make.height.mas_equalTo(2);
            make.centerX.mas_equalTo(_currentBtn);
            make.top.mas_equalTo(_currentBtn.mas_bottom).mas_equalTo(0);
        }];
        _lineView.backgroundColor=kRGBColor(56, 106, 198);
    }
    return _lineView;
}

- (UIView *)naviView
{
    if (!_naviView) {
        _naviView = [UIView new];
        NSArray *arr = @[@"蹿红",@"周榜",@"月榜"];
        UIView *lastView = nil;
        for (int i = 0; i < arr.count; i++) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:arr[i] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            [btn setTitleColor:kRGBColor(56, 106, 198) forState:UIControlStateSelected];
            btn.titleLabel.font = [UIFont systemFontOfSize:16];
            if (i == 0) {
                _currentBtn = btn;
                btn.selected = YES;
            }
            [btn bk_addEventHandler:^(UIButton *sender) {
                if (_currentBtn != sender) {
                    _currentBtn.selected = NO;
                    sender.selected = YES;
                    
                    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
                        make.width.mas_equalTo((kWindowW-40)/3);
                        make.height.mas_equalTo(2);
                        make.centerX.mas_equalTo(sender);
                        make.top.mas_equalTo(sender.mas_bottom).mas_equalTo(0);
                    }];

                    
                    _currentBtn = sender;
                    _sdVC.currentPage = [_btns indexOfObject:sender];
                }
            } forControlEvents:UIControlEventTouchUpInside];
            
            
            [self.naviView addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.size.mas_equalTo(CGSizeMake((kWindowW-40)/3, 25));
                make.centerY.mas_equalTo(self.naviView);
                if (lastView) {
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(10);
                }else{
                    make.left.mas_equalTo(10);
                }
            }];
            lastView = btn;
            [self.btns addObject:btn];
        }
       [lastView mas_updateConstraints:^(MASConstraintMaker *make) {
           make.right.mas_equalTo(_naviView.mas_right).mas_equalTo(-10);
       }];
    }
    return _naviView;
}

- (RankListViewController *)latestVCWithType:(RankType)type{
    RankListViewController *vc = kVCFromSb(@"RankListViewController", @"Main");
    vc.type = type;
    return vc;
}
- (ScrollDisplayViewController *)sdVC{
    if (!_sdVC) {
        NSArray*vcs=@[[self latestVCWithType:RankTypeCuanHong],
                      [self latestVCWithType:RankTypeZhouBang],
                      [self latestVCWithType:RankTypeYueBang],
                      ];
        _sdVC=[[ScrollDisplayViewController alloc] initWithControllers:vcs];
        _sdVC.autoCycle = NO;
        _sdVC.showPageControl = NO;
        _sdVC.delegate = self;
    }
    return _sdVC;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.lineView.hidden = NO;
    self.navigationItem.title = @"排行";
    
    [self addChildViewController:self.sdVC];
    [self.view addSubview:self.sdVC.view];
    [self.sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    
    [self.view addSubview:self.naviView];
//    self.naviView.backgroundColor = [UIColor redColor];
    [self.naviView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.left.mas_equalTo(0);
        make.top.mas_equalTo(0);
        make.height.mas_equalTo(30);
    }];
    
    // Do any additional setup after loading the view.
//    [self addChildViewController:self.sdVC];
//    [self.view addSubview:self.sdVC.view];
//    [self.sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.mas_equalTo(self.view);
//    }];
//    [self.navigationController.navigationBar addSubview:self.scrollView];
//    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.left.right.mas_equalTo(0);
//        make.height.mas_equalTo(44);
//    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
