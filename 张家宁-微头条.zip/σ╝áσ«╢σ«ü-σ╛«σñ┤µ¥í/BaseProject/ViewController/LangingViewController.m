//
//  LangingViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LangingViewController.h"
#import "UMSocial.h"
#import "MyViewController.h"
#import "MyTabBarController.h"

@interface LangingViewController ()
//@property (nonatomic,strong)NSString *InfoPath;
//@property (nonatomic,strong)NSString *name;
//@property (nonatomic,strong)NSString *iconPath;
@property (nonatomic,strong)NSUserDefaults *userDefault;;
@end

@implementation LangingViewController
- (NSUserDefaults *)userDefault
{
    if (!_userDefault) {
        _userDefault = [NSUserDefaults standardUserDefaults];
    }
    return _userDefault;
}

//- (NSString *)InfoPath
//{
//    if (!_InfoPath) {
//        NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
//        _InfoPath = [docPath stringByAppendingString:@"oneInfo"];
//    }
//    return _InfoPath;
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *iamgeView = [UIImageView new];
    iamgeView.image = [UIImage imageNamed:@"背景图"];
    [self.view addSubview:iamgeView];
    [iamgeView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.left.mas_equalTo(0);
        make.top.mas_equalTo(0);
    }];
    iamgeView.userInteractionEnabled = YES;
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [iamgeView addSubview:backBtn];
//    backBtn.backgroundColor = [UIColor redColor];
    [backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(40);
        make.left.mas_equalTo(20);
        make.size.mas_equalTo(CGSizeMake(20, 20));
    }];
    [backBtn setBackgroundImage:[UIImage imageNamed:@"返回点击效果"] forState:UIControlStateNormal];
    [backBtn bk_addEventHandler:^(id sender) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } forControlEvents:UIControlEventTouchUpInside];
    UIImageView *headView = [UIImageView new];
    headView.image = [UIImage imageNamed:@"share_微信"];
    [self.view addSubview:headView];
    [headView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(kWindowH*0.2);
        make.size.mas_equalTo(CGSizeMake(70, 70));
        make.centerX.mas_equalTo(0);
    }];
    UILabel *Lb = [UILabel new];
    Lb.text = @"趣味内容分享平台";
    Lb.textColor = [UIColor lightGrayColor];
    [self.view addSubview:Lb];
    [Lb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(headView.mas_bottom).mas_equalTo(20);
        make.centerX.mas_equalTo(0);
    }];
    UIButton *WeCharBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [WeCharBtn setBackgroundImage:[UIImage imageNamed:@"share_微信"] forState:UIControlStateNormal];
    [self.view addSubview:WeCharBtn];
    [WeCharBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(50, 50));
        make.bottom.mas_equalTo(-kWindowH*0.2);
        make.left.mas_equalTo(95);
    }];
    [WeCharBtn bk_addEventHandler:^(id sender) {
        UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToWechatSession];
        
        snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
            
            if (response.responseCode == UMSResponseCodeSuccess) {
                
                UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary]valueForKey:UMShareToWechatSession];
                
                NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
                
            }
            
        });
    } forControlEvents:UIControlEventTouchUpInside];
    UIButton *WieBoBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [WieBoBtn setBackgroundImage:[UIImage imageNamed:@"share_微博"] forState:UIControlStateNormal];
    [self.view addSubview:WieBoBtn];
    [WieBoBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(50, 50));
        make.bottom.mas_equalTo(-kWindowH*0.2);
        make.right.mas_equalTo(-95);
    }];
    [WieBoBtn bk_addEventHandler:^(id sender) {
        UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
        
        snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
            
            //          获取微博用户名、uid、token等
            
            if (response.responseCode == UMSResponseCodeSuccess) {
                
                UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
//                
//                NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
//                self.name = snsAccount.usid;
//                self.iconPath = snsAccount.iconURL;
                [self.userDefault setValue:snsAccount.userName forKey:@"name"];
                [self.userDefault setValue:snsAccount.iconURL forKey:@"iconUrl"];
                [self.userDefault synchronize];
                NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
                NSDictionary *userInfo = @{@"name":snsAccount.userName,@"iconUrl":snsAccount.iconURL};
                [center postNotificationName:@"Update" object:self userInfo:userInfo];
            }});
        [self.navigationController popToRootViewControllerAnimated:YES];
        
        
    } forControlEvents:UIControlEventTouchUpInside];
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSLog(@"path = %@",path);
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
