//
//  MyViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MyViewController.h"
#import "LangingViewController.h"
#import "UMSocial.h"
@interface MyCell : UITableViewCell
@property (nonatomic,strong)UIImageView *imageView1;
@property (nonatomic,strong)UILabel *title;
@property (nonatomic,strong)UILabel *dec;
@end
@implementation MyCell

- (UIImageView *)imageView1
{
    if (!_imageView1) {
        _imageView1 = [UIImageView new];
        [self.contentView addSubview:_imageView1];
        [_imageView1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(6);
            make.size.mas_equalTo(CGSizeMake(25, 25));
            make.centerY.mas_equalTo(0);
        }];
    }
    return _imageView1;
}
- (UILabel *)title
{
    if (!_title) {
        _title = [UILabel new];
        [self.contentView addSubview:_title];
        [_title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imageView1.mas_right).mas_equalTo(8);
            make.centerY.mas_equalTo(0);
        }];
    }
    return _title;
}
- (UILabel *)dec
{
    if (!_dec) {
        _dec = [UILabel new];
        [self.contentView addSubview:_dec];
        [_dec mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.right.mas_equalTo(0);
        }];
        _dec.textColor = [UIColor lightGrayColor];
        _dec.font = [UIFont systemFontOfSize:16];
    }
    return _dec;
}


@end


@interface MyViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)UIView *Headview;
@property (nonatomic,strong)NSString *Infoname;
@property (nonatomic,strong)NSString *InfoIV;
@property (nonatomic,strong)NSUserDefaults *userDefaults;
@property (nonatomic)BOOL isHas;
@property (nonatomic,strong)UIButton *btn;
@property (nonatomic,strong)UIImageView *imageView2;
@end

@implementation MyViewController

- (UIButton *)btn
{
    if (!_btn ) {
        _btn = [UIButton buttonWithType:UIButtonTypeSystem];
        [self.Headview addSubview:_btn];
        [_btn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(100, 50));
            make.top.mas_equalTo(self.imageView2.mas_bottom).mas_equalTo(0);
        }];
        [_btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        if ([self.userDefaults valueForKey:@"name"]) {
            [self.btn setTitle:[self.userDefaults valueForKey:@"name"] forState:UIControlStateNormal];
        }else{
            
            [_btn setTitle:@"点击登录" forState:UIControlStateNormal];
        }
        [_btn bk_addEventHandler:^(id sender) {
            LangingViewController *vc = [LangingViewController new];
            [self presentViewController:vc animated:YES completion:nil];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _btn;
}
- (UIImageView *)imageView2
{
    if (!_imageView2) {
        _imageView2 = [UIImageView new];
        [self.view addSubview:_imageView2];
        [_imageView2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(80, 80));
            make.top.mas_equalTo(90);
        }];
        _imageView2.layer.cornerRadius = 40;
        _imageView2.clipsToBounds = YES;
        if ([self.userDefaults valueForKey:@"iconUrl"]) {
            [self.imageView2 setImageWithURL:[self.userDefaults valueForKey:@"iconUrl"]];
        }
        _imageView2.image = [UIImage imageNamed:@"无头像状态"];
    }
    return _imageView2;
}



- (void)receiveNotification:(NSNotification *)notification
{
    [self.btn setTitle:notification.userInfo[@"name"] forState:UIControlStateNormal];
    [self.imageView2 setImageWithURL:[NSURL URLWithString:notification.userInfo[@"iconUrl"]]];
    
}

-(NSUserDefaults *)userDefaults
{
    if (!_userDefaults) {
        _userDefaults = [NSUserDefaults standardUserDefaults];
    }
    return _userDefaults;
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.sectionHeaderHeight = 3;
        _tableView.sectionFooterHeight = 3;
        [_tableView registerClass:[MyCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:_tableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(0);
            make.top.mas_equalTo(self.Headview.mas_bottom).mas_equalTo(0);
        }];
    
    }
    return _tableView;
}


- (UIView *)Headview
{
    if (!_Headview) {
        _Headview = [UIView new];
        _Headview.backgroundColor = [UIColor redColor];
        [self.view addSubview:self.Headview];
        [_Headview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(20);
            make.left.right.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(kWindowW, kWindowW * 165/268));
        }];
        UIImageView *imageView =[UIImageView new];
        imageView.image = [UIImage imageNamed:@"头像背景"];
        [self.Headview addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeSystem];
        [btn2 setBackgroundImage:[UIImage imageNamed:@"个人设置-0"] forState:UIControlStateNormal];
        [self.view addSubview:btn2];
        [btn2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-20);
            make.top.mas_equalTo(40);
            make.size.mas_equalTo(CGSizeMake(30, 30));
        }];
        [btn2 bk_addEventHandler:^(id sender) {
            [self.userDefaults removeObjectForKey:@"name"];
            [self.userDefaults setValue:nil forKey:@"iconUrl"];
        
            self.Infoname = nil;
            self.Infoname = [self.userDefaults valueForKey:@"name"];
            if (self.Infoname) {
                [_btn setTitle:self.Infoname forState:UIControlStateNormal];
            }else{
                [_btn setTitle:@"点击登录" forState:UIControlStateNormal];
            }
            self.InfoIV = [self.userDefaults valueForKey:@"iconUrl"];
            if (self.InfoIV) {
                _imageView2.layer.cornerRadius = 40;
                _imageView2.clipsToBounds = YES;
                [_imageView2 setImageWithURL:[NSURL URLWithString:self.InfoIV]];
            }else{
                _imageView2.image = [UIImage imageNamed:@"无头像状态"];
            }


        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _Headview;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 4;
    }
    else
    {
        return 1;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.imageView1.image = [UIImage imageNamed:@"我的消息"];
            cell.title.text = @"我的消息";
            cell.dec.text = @"评论我的/通知";
        }
        else if (indexPath.row == 1)
        {
            cell.imageView1.image = [UIImage imageNamed:@"我的动态"];
            cell.title.text = @"我的动态";
        }
        else if (indexPath.row == 2)
        {
            cell.imageView1.image = [UIImage imageNamed:@"积分任务"];
            cell.title.text = @"积分任务";
        }
        else
        {
            cell.imageView1.image = [UIImage imageNamed:@"每日推送"];
            cell.title.text = @"每日推送";
        }
        }
    else
    {
        cell.imageView1.image = [UIImage imageNamed:@"设置"];
        cell.title.text = @"设置";
        
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (![self.userDefaults valueForKey:@"name"]) {
        
        if (indexPath.section == 0) {
            
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"登陆后使用" message:nil preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"在逛逛" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            UIAlertAction *other = [UIAlertAction actionWithTitle:@"去登陆" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                
            }];
            [alert addAction:cancel];
            [alert addAction:other];
            [self presentViewController:alert animated:YES completion:nil];
            
        }
    }
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 10;
    }
    else
    {
        return 5;
    }
    
    
}




- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.btn.hidden = NO;
    self.Headview.hidden = NO;
    self.tableView.hidden = NO;
    self.navigationController.navigationBar.hidden = YES;
    NSLog(@"界面已经加载");
    NSLog(@"%@",[self.userDefaults valueForKey:@"name"]);
}





- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated
{
    NSLog(@"界面即将显示");
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveNotification:) name:@"Update" object:nil];
}
- (void)viewWillDisappear:(BOOL)animated
{
    NSLog(@"界面即将消失");
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
