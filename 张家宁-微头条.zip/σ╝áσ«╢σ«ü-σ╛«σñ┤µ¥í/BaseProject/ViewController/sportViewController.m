//
//  sportViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportViewController.h"
#import "sportVidoeViewController.h"
#import "sportDescViewController.h"
@interface OneCell : UITableViewCell
@property (nonatomic,strong)UIImageView *IView;
@property (nonatomic,strong)UILabel *titleLb;
@property (nonatomic,strong)UILabel *descLb;
@property (nonatomic,strong)UILabel *clickLb;

@end

@implementation OneCell
- (UIImageView *)IView
{
    if (!_IView) {
        _IView = [UIImageView new];
        [self.contentView addSubview:_IView];
        [_IView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(8);
            make.size.mas_equalTo(CGSizeMake(90, 70));
            make.centerY.mas_equalTo(0);
        }];
        _IView.contentMode = UIViewContentModeRedraw;
    }
    return _IView;
}

- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [UILabel new];
        [self.contentView addSubview:_titleLb];
        _titleLb.font = [UIFont systemFontOfSize:16];
        _titleLb.numberOfLines = 0;
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(8);
            make.left.mas_equalTo(self.IView.mas_right).mas_equalTo(6);
            make.right.mas_equalTo(-10);
        }];
    }
    return _titleLb;
}
- (UILabel *)descLb
{
    if (!_descLb) {
        _descLb = [UILabel new];
        [self.contentView addSubview:_descLb];
        _descLb.font = [UIFont systemFontOfSize:15];
        _descLb.textColor = [UIColor lightGrayColor];
        _descLb.numberOfLines = 0;
        [_descLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.titleLb.mas_bottom).mas_equalTo(4);
            make.leftMargin.mas_equalTo(self.titleLb.mas_leftMargin);
            make.right.mas_equalTo(-10);
        }];
    }
    return _descLb;
}
- (UILabel *)clickLb
{
    if (!_clickLb) {
        _clickLb = [UILabel new];
        [self.contentView addSubview:_clickLb];
        _clickLb.font = [UIFont systemFontOfSize:12];
        _clickLb.textColor = [UIColor lightGrayColor];
        [_clickLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.bottom.mas_equalTo(-5);
        }];
    }
    return _clickLb;
}

@end

@interface iconCell : UITableViewCell
@property (nonatomic,strong)UIImageView *iV1;
@property (nonatomic,strong)UIImageView *iV2;
@property (nonatomic,strong)UIImageView *iV3;
@property (nonatomic,strong)UILabel *tilteLb1;
@property (nonatomic,strong)UILabel *clickIcon;
@end
@implementation iconCell

- (UILabel *)tilteLb1
{
    if (!_tilteLb1) {
        _tilteLb1 = [UILabel new];
        [self.contentView addSubview:_tilteLb1];
        _tilteLb1.font = [UIFont systemFontOfSize:16];
        [_tilteLb1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(8);
        }];
    }
    return _tilteLb1;
}

- (UIImageView *)iV1
{
    if (!_iV1) {
        _iV1 = [UIImageView new];
        [self.contentView addSubview:_iV1];
        [_iV1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(8);
            make.size.mas_equalTo(CGSizeMake((kWindowW-22)/3, 95));
            make.top.mas_equalTo(self.tilteLb1.mas_bottom).mas_equalTo(2);
        }];
    }
    return _iV1;
}
- (UIImageView *)iV2
{
    if (!_iV2) {
        _iV2 = [UIImageView new];
        [self.contentView addSubview:_iV2];
        [_iV2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iV1.mas_right).mas_equalTo(3);
            make.topMargin.mas_equalTo(self.iV1.mas_topMargin);
            make.size.mas_equalTo(self.iV1);
        }];
    }
    return _iV2;
}
- (UIImageView *)iV3
{
    if (!_iV3) {
        _iV3 = [UIImageView new];
        [self.contentView addSubview:_iV3];
        [_iV3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.iV2.mas_right).mas_equalTo(3);
            make.topMargin.mas_equalTo(self.iV1.mas_topMargin);
            make.size.mas_equalTo(self.iV1);
        }];
    }
    return _iV3;
}
- (UILabel *)clickIcon
{
    if (!_clickIcon) {
        _clickIcon = [UILabel new];
        [self.contentView addSubview:_clickIcon];
        _clickIcon.font = [UIFont systemFontOfSize:12];
        _clickIcon.textColor = [UIColor lightGrayColor];
        [_clickIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(-3);
            make.right.mas_equalTo(-5);
        }];
    }
    return _clickIcon;
}


@end


@interface sportViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)sportViewModel *SPVM;
@end

@implementation sportViewController


-(sportViewModel *)SPVM
{
    if (!_SPVM) {
        _SPVM = [sportViewModel new];
    }
    return _SPVM;
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [UITableView new];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[iconCell class] forCellReuseIdentifier:@"iconCell"];
        [_tableView registerClass:[OneCell class] forCellReuseIdentifier:@"Cell"];
    }
    return _tableView;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.SPVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (![self.SPVM isHasIconForRow:indexPath.row]) {
         OneCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.IView setImageWithURL:[self.SPVM iconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"体育加载"]];
    cell.titleLb.text = [self.SPVM titleForRow:indexPath.row];
    cell.descLb.text = [self.SPVM descForRow:indexPath.row];
    cell.clickLb.text = [self.SPVM clickForRow:indexPath.row];
        return cell;
    }else{
        iconCell *cell = [tableView dequeueReusableCellWithIdentifier:@"iconCell"];
        [cell.iV1 setImageWithURL:[NSURL URLWithString:[self.SPVM path0ForRow:indexPath.row]]];
        [cell.iV2 setImageWithURL:[NSURL URLWithString:[self.SPVM path1ForRow:indexPath.row]]];
        [cell.iV3 setImageWithURL:[NSURL URLWithString:[self.SPVM path2ForRow:indexPath.row]]];
        cell.tilteLb1.text = [self.SPVM titleForRow:indexPath.row];
        cell.clickIcon.text = [self.SPVM clickForRow:indexPath.row];
        return cell;
    }
   
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"体育";
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.SPVM refreshDataCompletionHandle:^(NSError *error) {
           if (error) {
               [self.tableView showErrorMsg:error.localizedDescription];
           }
           [self.tableView reloadData];
           [self.tableView.header endRefreshing];
           
       }];
    }];
    self.tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
       [self.SPVM getMoreDataCompletionHandle:^(NSError *error) {
           [self.tableView reloadData];
           [self.tableView.footer endRefreshing];
       }];
    }];
    
    [self.tableView.header beginRefreshing];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (![self.SPVM isHasIconForRow:indexPath.row]) {
        return 86;
    }
    return 143;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row == 6) {
        sportVidoeViewController *vc = [sportVidoeViewController new];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        sportDescViewController *vc = [[sportDescViewController alloc]initWithNid:[self.SPVM sportdescForRow:indexPath.row]];
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
