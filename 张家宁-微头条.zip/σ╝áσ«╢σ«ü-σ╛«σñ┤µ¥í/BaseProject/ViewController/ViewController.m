//
//  ViewController.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ViewController.h"
#import "WTTViewModel.h"
#import "oneCell.h"
#import "twoCell.h"
#import "decViewController.h"
@interface ViewController ()<UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@property (nonatomic,strong)WTTViewModel *WTTVM;
@end

@implementation ViewController

- (WTTViewModel *)WTTVM
{
    if (!_WTTVM) {
        _WTTVM = [[WTTViewModel alloc]initWithNewsListType:_type];
    }
    return _WTTVM;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tabBarController.tabBar.hidden = NO;
    
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.WTTVM refreshDataCompletionHandle:^(NSError *error) {
           [self.collectionView reloadData];
           [self.collectionView.header endRefreshing];
       }];
    }];
    
    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.WTTVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.collectionView reloadData];
            [self.collectionView.footer endRefreshing];
        }];
    }];
    [self.collectionView.header beginRefreshing];
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.WTTVM.rowNumber;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.item % 7 == 0) {
        oneCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:@"oneCell" forIndexPath:indexPath];
        [cell.btn1 setBackgroundImageForState:UIControlStateNormal withURL:[self.WTTVM iconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"新闻加载"]];
        cell.btn1.userInteractionEnabled = NO;
//        [cell.btn1 bk_addEventHandler:^(id sender) {
//            decViewController *vc = [decViewController new];
//            [self.navigationController pushViewController:vc animated:YES];
////            self.hidesBottomBarWhenPushed = YES;
//        } forControlEvents:UIControlEventTouchUpInside];
        cell.titleLb1.text = [self.WTTVM titleForRow:indexPath.row];
        cell.clicks.text = @([self.WTTVM clickForRow:indexPath.row]).stringValue;
        
        return cell;
    }
    else
    {
        twoCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:@"twoCell" forIndexPath:indexPath];
        cell.layer.borderColor = kRGBColor(224, 224, 224).CGColor;
        cell.layer.borderWidth = 0.4;
    [cell.btn2 setBackgroundImageForState:UIControlStateNormal withURL:[self.WTTVM iconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"新闻加载"]];
    cell.btn2.userInteractionEnabled = NO;
    cell.titleLb2.text = [self.WTTVM titleForRow:indexPath.row];
    cell.clicks2.text = @([self.WTTVM clickForRow:indexPath.row]).stringValue;
        cell.imageH.constant = kWindowW / 2 * 150 / 245;
        return cell;
    }
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.item % 7 == 0) {
        return CGSizeMake(kWindowW, kWindowW * 200/360);
    }
    return CGSizeMake(kWindowW/2, kWindowW/2 * 280/270);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    decViewController *vc = [[decViewController alloc]initDecWithAck:[self.WTTVM PathAckForRow:indexPath.row] Id:[self.WTTVM PathIdForRow:indexPath.row]];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
