//
//  sportDescViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportDescViewController.h"
#import "uploadView.h"
@interface sportDescViewController ()
@property (nonatomic,strong)UIWebView *sportDescWeb;
@property (nonatomic,strong)uploadView *view1;
@end

@implementation sportDescViewController

- (UIView *)view1
{
    if (!_view1) {
        _view1 = [uploadView new];
        [self.view addSubview:_view1];
        _view1.backgroundColor = [UIColor whiteColor];
        [_view1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _view1;
}

- (id)initWithNid:(NSString *)nid
{
    if (self = [super init]) {
        _nid = nid;
    }
    return self;
}

- (UIWebView *)sportDescWeb
{
    if (!_sportDescWeb) {
        _sportDescWeb = [UIWebView new];
    }
    return _sportDescWeb;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view addSubview:self.sportDescWeb];
//    _sportDescWeb.backgroundColor = [UIColor redColor];
    [self.sportDescWeb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    NSString *path = [NSString stringWithFormat:@"http://kanqiu.hupu.com/s?u=nba/news/%@",self.nid];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:path]];
    [self.sportDescWeb loadRequest:request];
}

- (void)viewWillAppear:(BOOL)animated
{
    [self.view1 upload];
}
- (void)viewDidAppear:(BOOL)animated
{
    [self.view1 removeFromSuperview];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
