//
//  RankListViewController.m
//  微头条
//
//  Created by apple-jd20 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankListViewController.h"
#import "RankDecViewController.h"

@interface RankListCell : UITableViewCell
@property (nonatomic,strong)UIImageView *RLimageView;
@property (nonatomic,strong)UILabel *title;
@property (nonatomic,strong)UILabel *clike;
@property (nonatomic,strong)UIImageView *imageView2;
@end
@implementation RankListCell

- (UIImageView *)imageView2
{
    if (!_imageView2) {
        _imageView2 = [UIImageView new];
        [self.contentView addSubview:_imageView2];
        [_imageView2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.RLimageView.mas_left).mas_equalTo(0);
            make.top.mas_equalTo(self.RLimageView.mas_top).mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(18, 18));
        }];
    }
    return _imageView2;
}

- (UIImageView *)RLimageView
{
    if (!_RLimageView) {
        _RLimageView = [UIImageView new];
        [self.contentView addSubview:_RLimageView];
        
        [_RLimageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(8);
            make.size.mas_equalTo(CGSizeMake(90, 60));
            make.centerY.mas_equalTo(0);
        }];
    }
    return _RLimageView;
}

- (UILabel *)title
{
    if (!_title) {
        _title = [UILabel new];
        [self.contentView addSubview:_title];
        _title.font = [UIFont systemFontOfSize:15];
        _title.numberOfLines = 0;
        [_title mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.RLimageView.mas_right).mas_equalTo(4);
            make.top.mas_equalTo(9);
            make.right.mas_equalTo(-10);
        }];
    }
    return _title;
}

- (UILabel *)clike
{
    if (!_clike) {
        _clike = [UILabel new];
        [self.contentView addSubview:_clike];
        _clike.textColor = [UIColor lightGrayColor];
        _clike.font = [UIFont systemFontOfSize:12];
        [_clike mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-5);
            make.bottom.mas_equalTo(-5);
        }];
    }
    return _clike;
}

@end


@interface RankListViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)RankListVIewModel *RLMV;
@end

@implementation RankListViewController

- (RankListVIewModel *)RLMV
{
    if (!_RLMV) {
        _RLMV = [[RankListVIewModel alloc]initWithType:self.type];
    }
    return _RLMV;
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [UITableView new];
        [self.view addSubview:_tableView];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        [_tableView registerClass:[RankListCell class] forCellReuseIdentifier:@"Cell"];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(30);
            make.right.left.bottom.mas_equalTo(0);
        }];
    }
    return _tableView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.RLMV getDataFromNetCompleteHandle:^(NSError *error) {
           [self.tableView reloadData];
           [self.tableView.header endRefreshing];
       }];
    }];
    [self.tableView.header beginRefreshing];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.RLMV.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    RankListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.RLimageView setImageWithURL:[self.RLMV iconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"加载背景"]];
    cell.title.text = [self.RLMV titleForRow:indexPath.row];
    if ([self.RLMV cilkeForRow:indexPath.row] >= 10000) {
        NSInteger i = [self.RLMV cilkeForRow:indexPath.row] / 10000;
        cell.clike.text = [NSString stringWithFormat:@"%ld万+",i];
    }
    else
    {
        cell.clike.text = @([self.RLMV cilkeForRow:indexPath.row]).stringValue;
    }

    if (indexPath.row < 10) {
        cell.imageView2.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld",indexPath.row + 1]];
        cell.imageView2.alpha = 1;
    }else {
        cell.imageView2.alpha = 0;
    }
    
     return cell;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 75;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    RankDecViewController *vc = [[RankDecViewController alloc]initWithAck:[self.RLMV PathAckForRow:indexPath.row] stream:[self.RLMV pathStreamForRow:indexPath.row]];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
