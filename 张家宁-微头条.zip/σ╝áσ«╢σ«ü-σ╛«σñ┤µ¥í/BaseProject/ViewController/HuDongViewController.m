//
//  HuDongViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HuDongViewController.h"
#import "ThreeCell.h"
#import "WTTViewModel.h"
#import "decViewController.h"
@interface HuDongViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (nonatomic,strong)WTTViewModel *WTTVM;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end

@implementation HuDongViewController

- (WTTViewModel *)WTTVM
{
    if (!_WTTVM) {
        _WTTVM = [[WTTViewModel alloc]initWithNewsListType:_type];
    }
    return _WTTVM;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.WTTVM.rowNumber;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ThreeCell *cell = [self.collectionView dequeueReusableCellWithReuseIdentifier:@"ThreeCell" forIndexPath:indexPath];
    [cell.btn setBackgroundImageForState:UIControlStateNormal withURL:[self.WTTVM iconForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"新闻加载"]];
    cell.btn.userInteractionEnabled = NO;
    cell.titleTb.text = [self.WTTVM titleForRow:indexPath.row];
    cell.Tb.text = [NSString stringWithFormat:@"%ld人以参与",[self.WTTVM clickForRow:indexPath.row]];
    return cell;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(kWindowW, kWindowW * 160 / 350);
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.WTTVM refreshDataCompletionHandle:^(NSError *error) {
                [self.collectionView reloadData];
                [self.collectionView.header endRefreshing];
        }];
    }];
    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
       [self.WTTVM getMoreDataCompletionHandle:^(NSError *error) {
           [self.collectionView reloadData];
           [self.collectionView.footer endRefreshing];
       }];
    }];
    [self.collectionView.header beginRefreshing];
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    decViewController *vc = [[decViewController alloc]initDecWithAck:[self.WTTVM PathAckForRow:indexPath.row] Id:[self.WTTVM PathIdForRow:indexPath.row]];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
