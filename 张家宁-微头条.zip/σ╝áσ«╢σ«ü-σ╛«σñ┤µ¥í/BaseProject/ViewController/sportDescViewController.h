//
//  sportDescViewController.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sportDescViewController : UIViewController
-(id)initWithNid:(NSString *)nid;
@property (nonatomic,strong)NSString *nid;
@end
