//
//  WelcomeViewController.m
//  微头条
//
//  Created by apple-jd20 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WelcomeViewController.h"
#import "WTTViewController.h"
#import "MyTabBarController.h"
#define kcount 4
@interface WelcomeViewController ()<UIScrollViewDelegate>
@property (nonatomic,strong)UIScrollView *scrollView;
@property (nonatomic,strong)UIPageControl *pageControl;
@end

@implementation WelcomeViewController
- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        [self.view addSubview:_scrollView];
        _scrollView.delegate = self;
        _scrollView.bounces = NO;
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.frame = self.view.bounds;
        _scrollView.contentSize = CGSizeMake(kcount * self.view.bounds.size.width, self.view.bounds.size.height);
        [self.view addSubview:self.pageControl];
        [self.pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(0);
            make.bottom.mas_equalTo(_scrollView.mas_bottom).mas_equalTo(-30);
            make.size.mas_equalTo(CGSizeMake(100, 20));
        }];
    }
    return _scrollView;
}
- (UIPageControl *)pageControl
{
    if (!_pageControl) {
        _pageControl = [UIPageControl new];
        _pageControl.pageIndicatorTintColor = [UIColor redColor];
        _pageControl.currentPageIndicatorTintColor = [UIColor blackColor];
        _pageControl.numberOfPages = kcount;
        _pageControl.userInteractionEnabled = NO;
    }
    return _pageControl;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (int i = 0; i < kcount; i++) {
        UIImageView *imageView = [UIImageView new];
        NSString *imageName = [NSString stringWithFormat:@"引导页面%d",i+1];
        imageView.image = [UIImage imageNamed:imageName];
        imageView.frame = CGRectMake(i*self.scrollView.frame.size.width, 0, self.scrollView.frame.size.width, self.scrollView.frame.size.height);
        [self.scrollView addSubview:imageView];
        if (i == kcount - 1) {
            imageView.userInteractionEnabled = YES;
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
            
            [imageView addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.edges.mas_equalTo(0);
            }];
            [btn setBackgroundImage:imageView.image forState:UIControlStateNormal];
            
            [btn bk_addEventHandler:^(id sender) {
                
            MyTabBarController *vc = [kStoryboard(@"Main") instantiateViewControllerWithIdentifier:@"MyTabBarController"];
                [self presentViewController:vc animated:YES completion:nil];
                
            } forControlEvents:UIControlEventTouchUpInside];
            
        }
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGPoint point = scrollView.contentOffset;
    double i = point.x / self.scrollView.frame.size.width;
    self.pageControl.currentPage = round(i);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
