//
//  RankDecViewController.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RankDecViewController : UIViewController

-(id)initWithAck:(NSString *)ack stream:(NSString *)stream;

@property (nonatomic,strong)NSString *ack;
@property (nonatomic,strong)NSString *stream;

@end
