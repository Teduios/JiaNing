//
//  VidoeViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VidoeViewController.h"

@interface VidoeViewController ()
@property (nonatomic,strong)UIWebView *Web1;
@end

@implementation VidoeViewController

- (id)initWithNid:(NSString *)nid
{
    if (self = [super init]) {
        _nid = nid;
    }
    return self;
}

- (UIWebView *)Web1
{
    if (!_Web1) {
        _Web1 = [UIWebView new];
    }
    return _Web1;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.Web1];
    [self.Web1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.nid]];
    [self.Web1 loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
