//
//  RankDecViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RankDecViewController.h"
#import "uploadView.h"
@interface RankDecViewController ()
@property (nonatomic,strong)UIWebView *Web;
@property (nonatomic,strong)uploadView *view1;
@end

@implementation RankDecViewController
- (UIView *)view1
{
    if (!_view1) {
        _view1 = [uploadView new];
        [self.view addSubview:_view1];
        _view1.backgroundColor = [UIColor whiteColor];
        [_view1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _view1;
}

-(id)initWithAck:(NSString *)ack stream:(NSString *)stream
{
    if (self = [super init]) {
        _ack = ack;
        _stream = stream;
    }
    return self;
}

- (UIWebView *)Web
{
    if (!_Web) {
        _Web = [UIWebView new];
    }
    return _Web;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.Web];
    [self.Web mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    NSString *path = [NSString stringWithFormat:@"http://app.lerays.com/stream/app/view?stream_id=%@&_ack=%@&from=wtt-app",self.stream,self.ack];
    NSURL *url = [NSURL URLWithString:path];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.Web loadRequest:request];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated
{
    [self.view1 upload];
}
- (void)viewDidAppear:(BOOL)animated
{
    [self.view1 removeFromSuperview];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
