//
//  HuDongViewController.h
//  BaseProject
//
//  Created by apple-jd20 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ViewController.h"
#import "WTTNetManager.h"
@interface HuDongViewController : UIViewController
@property (nonatomic)InfoType type;
@end
