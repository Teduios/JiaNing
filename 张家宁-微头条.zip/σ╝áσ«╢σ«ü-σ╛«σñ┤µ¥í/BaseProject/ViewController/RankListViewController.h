//
//  RankListViewController.h
//  微头条
//
//  Created by apple-jd20 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RankListVIewModel.h"
@interface RankListViewController : UIViewController
@property (nonatomic)RankType type;
@end
