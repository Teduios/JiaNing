//
//  sportVidoeViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/20.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "sportVidoeViewController.h"
#import "VidoeViewController.h"
@interface sportVidoeCell : UITableViewCell
@property (nonatomic,strong)UIImageView *IView;
@property (nonatomic,strong)UILabel *titleLb;
@property (nonatomic,strong)UILabel *timeLb;
@property (nonatomic,strong)UILabel *clickLb;
@end
@implementation sportVidoeCell

- (UIImageView *)IView
{
    if (!_IView) {
        _IView = [UIImageView new];
        [self.contentView addSubview:_IView];
        [_IView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(8);
            make.size.mas_equalTo(CGSizeMake(90, 70));
            make.centerY.mas_equalTo(0);
        }];
        _IView.contentMode = UIViewContentModeRedraw;
    }
    return _IView;
}
- (UILabel *)titleLb
{
    if (!_titleLb) {
        _titleLb = [UILabel new];
        [self.contentView addSubview:_titleLb];
        _titleLb.font = [UIFont systemFontOfSize:16];
        _titleLb.numberOfLines = 0;
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(8);
            make.left.mas_equalTo(self.IView.mas_right).mas_equalTo(6);
            make.right.mas_equalTo(-10);
        }];
    }
    return _titleLb;
}
- (UILabel *)clickLb
{
    if (!_clickLb) {
        _clickLb = [UILabel new];
        [self.contentView addSubview:_clickLb];
        _clickLb.font = [UIFont systemFontOfSize:12];
        _clickLb.textColor = [UIColor lightGrayColor];
        [_clickLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.bottom.mas_equalTo(-5);
        }];
    }
    return _clickLb;
}

- (UILabel *)timeLb
{
    if (!_timeLb) {
        _timeLb = [UILabel new];
        [self.contentView addSubview:_timeLb];
        _timeLb.font = [UIFont systemFontOfSize:12];
        _timeLb.textColor = [UIColor lightGrayColor];
        [_timeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.clickLb.mas_left).mas_equalTo(-2);
            make.bottom.mas_equalTo(-5);
        }];
    }
    return _timeLb;
}


@end
@interface sportVidoeViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)sportVidoeVIewModel *SPVVM;
@property (nonatomic,strong)NSString *vidoePath;
@end

@implementation sportVidoeViewController

- (sportVidoeVIewModel *)SPVVM
{
    if (!_SPVVM) {
        _SPVVM = [sportVidoeVIewModel new];
    }
    return _SPVVM;
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [UITableView new];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        [_tableView registerClass:[sportVidoeCell class] forCellReuseIdentifier:@"Cell"];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.SPVVM.rowNumber;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    sportVidoeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.IView setImageWithURL:[self.SPVVM iconForRow:indexPath.row]placeholderImage:[UIImage imageNamed:@"体育加载"]];
    cell.titleLb.text = [self.SPVVM titleForRow:indexPath.row];
    cell.clickLb.text = [self.SPVVM clikeForRow:indexPath.row];
    cell.timeLb.text = [self.SPVVM timeForRow:indexPath.row];
    self.vidoePath = [self.SPVVM pathForRow:indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 86;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.SPVVM refreshDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self.tableView showErrorMsg:error.localizedDescription];
            }
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
            
        }];
    }];
    self.tableView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.SPVVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
    
    [self.tableView.header beginRefreshing];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    VidoeViewController *vc  = [[VidoeViewController alloc]initWithNid:self.vidoePath];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
