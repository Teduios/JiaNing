//
//  WTTViewController.m
//  BaseProject
//
//  Created by apple-jd20 on 15/11/11.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WTTViewController.h"
#import "ViewController.h"
#import "ScrollDisplayViewController.h"
#import "WTTNetManager.h"
@interface WTTViewController ()<ScrollDisplayViewControllerDelegate>
@property (nonatomic,strong)ScrollDisplayViewController *sdVC;
@property (nonatomic,strong)UIScrollView *scrollView;
@property (nonatomic,strong)NSMutableArray *btns;
@property (nonatomic,strong)UIButton *currentBtn;
@end

@implementation WTTViewController

- (void)scrollDisplayViewController:(ScrollDisplayViewController *)scrollDisplayViewController currentIndex:(NSInteger)index
{
    _currentBtn.selected =NO;
    _currentBtn = _btns[index];
    _currentBtn.selected = YES;
}

- (NSMutableArray *)btns
{
    if (!_btns) {
        _btns = [NSMutableArray new];
    }
    return _btns;
}
- (UIScrollView *)scrollView
{
    if (!_scrollView) {
        _scrollView = [UIScrollView new];
        NSArray *arr = @[@"热门",@"美女",@"互动",@"萌宠",@"奇趣",@"爆笑",@"视频",@"生活",@"资讯"];
        UIView *lastView = nil;
        for (int  i = 0; i < arr.count; i++) {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:arr[i] forState:UIControlStateNormal];
            [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [btn setTitleColor:kRGBColor(16, 70, 145) forState:UIControlStateSelected];
            if (i == 0) {
                _currentBtn = btn;
                btn.selected = YES;
            }
            [btn bk_addEventHandler:^(UIButton *sender) {
                if (_currentBtn != sender) {
                    _currentBtn.selected = NO;
                    sender.selected = YES;
                    _currentBtn = sender;
                    _sdVC.currentPage = [_btns indexOfObject:sender];
                }
            } forControlEvents:UIControlEventTouchUpInside];
            [_scrollView addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.size.mas_equalTo(CGSizeMake(45, 24));
                make.centerY.mas_equalTo(_scrollView);
                if (lastView) {
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(10);
                }
                else
                {
                    make.left.mas_equalTo(10);
                }
            }];
            lastView = btn;
            [self.btns addObject:btn];
        }
        [lastView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(_scrollView.mas_right).mas_equalTo(-10);
        }];
        _scrollView.showsHorizontalScrollIndicator = NO;
        
    }
    return _scrollView;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.scrollView.hidden = NO;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.scrollView.hidden = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addChildViewController:self.sdVC];
    [self.view addSubview:self.sdVC.view];
    [self.sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    self.scrollView.backgroundColor = kRGBColor(214, 203, 185);
    [self.navigationController.navigationBar addSubview:self.scrollView];
    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.mas_equalTo(0);
        make.height.mas_equalTo(44);
    }];
}

- (WTTViewController *)WTTVCWithType:(InfoType)type
{
    if (type != InfoTypeHuDong) {
        WTTViewController *vc = [kStoryboard(@"Main") instantiateViewControllerWithIdentifier:@"ViewController"];
        vc.type = type;
        return vc;
    }
    else
    {
//        WTTViewController *vc = [kStoryboard(@"Main") instantiateViewControllerWithIdentifier:@"HuDongViewController"];
        WTTViewController *vc = kVCFromSb(@"HuDongViewController", @"Main");
        vc.type = type;
        return vc;
    }
}
- (ScrollDisplayViewController *)sdVC
{
    if (!_sdVC) {
        NSArray *vcs = @[[self WTTVCWithType:InfoTypeReMen],
                         [self WTTVCWithType:InfoTypeMeiNv],
                         [self WTTVCWithType:InfoTypeHuDong],
                         [self WTTVCWithType:InfoTypeMengCong],
                         [self WTTVCWithType:InfoTypeQiQu],
                         [self WTTVCWithType:InfoTypeBaoXiao],
                         [self WTTVCWithType:InfoTypeShiPin],
                         [self WTTVCWithType:InfoTypeShengHuo],
                         [self WTTVCWithType:InfoTypeZiXun]
                         ];
        _sdVC = [[ScrollDisplayViewController alloc] initWithControllers:vcs];
        _sdVC.autoCycle = NO;
        _sdVC.showPageControl = NO;
        _sdVC.delegate = self;
    }
    return _sdVC;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
