//
//  decViewController.m
//  微头条
//
//  Created by apple-jd20 on 15/11/15.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "decViewController.h"
#import "UMSocial.h"
#import "uploadView.h"
@interface decViewController ()<UIWebViewDelegate>
@property (nonatomic,strong)UIWebView *web;
@property (nonatomic,strong)UIButton *btn;
@property (nonatomic,strong)uploadView *view1;
@end

@implementation decViewController

- (UIView *)view1
{
    if (!_view1) {
        _view1 = [uploadView new];
        [self.view addSubview:_view1];
        _view1.backgroundColor = [UIColor whiteColor];
        [_view1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _view1;
}





- (id)initDecWithAck:(NSString *)ack Id:(NSString *)Id
{
    if (self = [super init]) {
        _ack = ack;
        _Id = Id;
    }
    return self;
}

- (UIButton *)btn
{
    if (!_btn) {
        _btn = [UIButton buttonWithType:UIButtonTypeCustom];
        CGRect frame = _btn.frame;
        frame.size = CGSizeMake(30, 30);
        _btn.frame = frame;
        [_btn setBackgroundImage:[UIImage imageNamed:@"分享动画_52"] forState:UIControlStateNormal];
        [_btn bk_addEventHandler:^(id sender) {
            
            [UMSocialSnsService presentSnsIconSheetView:self
                                                 appKey:@"5652c654e0f55a3377002c42"
                                              shareText:[NSString stringWithFormat:@"http://app.lerays.com/stream/app/view?stream_id=%@&_ack=%@&from=wtt-app",self.Id,self.ack]
                                             shareImage:[UIImage imageNamed:@"新闻加载"]
                                        shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToWechatSession,UMShareToQQ,nil]
                                               delegate:nil];
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _btn;
}


- (UIWebView *)web
{
    if (!_web) {
        _web = [[UIWebView alloc]init];
        [self.view addSubview:_web];
        NSString *path = [NSString stringWithFormat:@"http://app.lerays.com/stream/app/view?stream_id=%@&_ack=%@&from=wtt-app",self.Id,self.ack];
        NSURL *url =[NSURL URLWithString:path];
        [_web loadRequest:[NSURLRequest requestWithURL:url]];
        [_web mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _web.delegate = self;
    }
    return _web;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBarController.tabBar.hidden = YES;
    self.web.hidden = NO;
    self.btn.hidden = NO;
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithCustomView:self.btn];
    self.navigationItem.rightBarButtonItem = item;
    
    UIBarButtonItem *barItemLeft = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStyleBordered target:self action:@selector(back)];
    [[self navigationItem] setLeftBarButtonItem:barItemLeft];
}
- (void)back
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
//    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
//    NSLog(@"error = %@",error);
}

-(void)viewDidAppear:(BOOL)animated
{
    NSLog(@"界面即将消失");
    [self.view1 removeFromSuperview];
}
- (void)viewDidDisappear:(BOOL)animated
{
    NSLog(@"加载界面即将消失");
}
- (void)viewWillAppear:(BOOL)animated
{
    NSLog(@"界面即将显示");
    
    [self.view1 upload];
}
- (void)viewWillDisappear:(BOOL)animated
{
    NSLog(@"加载界面即将显示");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





@end
